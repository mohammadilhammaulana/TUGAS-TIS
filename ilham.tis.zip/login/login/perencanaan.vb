﻿Public Class Perencanaan
    Dim strsql As String
    Dim info As String
    Private _no3 As Integer
    Private _idpetani As String
    Private _lahan As String
    Private _bibit As String
    Private _pengairan As String
    Private _pupuk As String
    Public InsertState As Boolean = False
    Public UpdateState As Boolean = False
    Public DeleteState As Boolean = False
    Public Property no3()
        Get
            Return _no3
        End Get
        Set(ByVal value)
            _no3 = value
        End Set
    End Property
    Public Property idpetani()
        Get
            Return _idpetani
        End Get
        Set(ByVal value)
            _idpetani = value
        End Set
    End Property
    Public Property lahan()
        Get
            Return _lahan
        End Get
        Set(ByVal value)
            _lahan = value
        End Set
    End Property
    Public Property bibit()
        Get
            Return _bibit
        End Get
        Set(ByVal value)
            _bibit = value
        End Set
    End Property
    Public Property pengairan()
        Get
            Return _pengairan
        End Get
        Set(ByVal value)
            _pengairan = value
        End Set
    End Property
    Public Property pupuk()
        Get
            Return _pupuk
        End Get
        Set(ByVal value)
            _pupuk = value
        End Set
    End Property
    Public Sub Simpan()
        Dim info As String
        DBConnect()
        If (perencanaan_baru = True) Then
            strsql = "Insert into perencanaan(idpetani,lahan,bibit,pengairan,pupuk) values ('" & _idpetani & "','" & _lahan & "','" & _bibit & "','" & _pengairan & "','" & _pupuk & "')"
            info = "INSERT"
        Else
            strsql = "update perencanaan set idpetani='" & _idpetani & "', lahan='" & _lahan & "', bibit='" & _bibit & "', pengairan='" & _pengairan & "', pupuk='" & _pupuk & "' where idpetani='" & _idpetani & "'"
            info = "UPDATE"
        End If
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
        Catch ex As Exception
            If (info = "INSERT") Then
                InsertState = False
            ElseIf (info = "UPDATE") Then
                UpdateState = False
            Else
            End If
        Finally
            If (info = "INSERT") Then
                InsertState = True
            ElseIf (info = "UPDATE") Then
                UpdateState = True
            Else
            End If
        End Try
        DBDisconnect()
    End Sub
    Public Sub Cariperencanaan(ByVal sidpetani As String)
        DBConnect()
        strsql = "SELECT * FROM perencanaan WHERE idpetani='" & sidpetani & "'"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        DR = myCommand.ExecuteReader
        If (DR.HasRows = True) Then
            perencanaan_baru = False
            DR.Read()
            idpetani = Convert.ToString((DR("idpetani")))
            lahan = Convert.ToString((DR("lahan")))
            bibit = Convert.ToString((DR("bibit")))
            pengairan = Convert.ToString((DR("pengairan")))
            pupuk = Convert.ToString((DR("pupuk")))
        Else
            MessageBox.Show("Data Tidak Ditemukan.")
            perencanaan_baru = True
        End If
        DBDisconnect()
    End Sub
    Public Sub Hapus(ByVal sidpetani As String)
        Dim info As String
        DBConnect()
        strsql = "DELETE FROM perencanaan WHERE idpetani='" & sidpetani & "'"
        info = "DELETE"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
            DeleteState = True
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        DBDisconnect()
    End Sub
    Public Sub getAllData(ByVal dg As DataGridView)
        Try
            DBConnect()
            strsql = "SELECT * FROM perencanaan"
            myCommand.Connection = conn
            myCommand.CommandText = strsql
            myData.Clear()
            myAdapter.SelectCommand = myCommand
            myAdapter.Fill(myData)
            With dg
                .DataSource = myData
                .AllowUserToAddRows = False
                .AllowUserToDeleteRows = False
                .ReadOnly = True
            End With
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        Finally
            DBDisconnect()
        End Try
    End Sub
End Class
