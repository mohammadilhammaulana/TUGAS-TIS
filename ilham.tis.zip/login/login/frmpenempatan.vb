﻿Public Class frmpenempatan

    Private Sub frmpenempatan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reload()
        openempatan.Caripenempatan(txtidlokasi.Text)
        If (biaya_baru = False) Then

        Else
            MessageBox.Show("Data TerLoad")
        End If
    End Sub
    Private Sub Reload()
        openempatan.getAllData(DataGridView3)
    End Sub
    Private Sub Tampilpenempatan()

        txtno2.Text = openempatan.no2
        txtidlokasi.Text = openempatan.idlokasi
        txtlokasi.Text = openempatan.lokasi
        txtluas.Text = openempatan.luas
        txtjnstanaman.Text = openempatan.jenistanamanyangcocokdilokasitsb


    End Sub
    Private Sub ClearEntry()
        txtno2.Clear()
        txtidlokasi.Clear()
        txtlokasi.Clear()
        txtluas.Clear()
        txtjnstanaman.Clear()
        txtidlokasi.Focus()
    End Sub
    Private Sub SimpanDataMenu()

        openempatan.no2 = txtno2.Text
        openempatan.idlokasi = txtidlokasi.Text
        openempatan.lokasi = txtlokasi.Text
        openempatan.luas = txtluas.Text
        openempatan.jenistanamanyangcocokdilokasitsb = txtjnstanaman.Text

        openempatan.Simpan()
        Reload()
        If (openempatan.InsertState = True) Then
            MessageBox.Show("Data berhasil disimpan.")
        ElseIf (openempatan.UpdateState = True) Then
            MessageBox.Show("Data berhasil diperbarui.")
        Else
            MessageBox.Show("Data gagal disimpan.")
        End If
        ClearEntry()
    End Sub
    Private Sub Hapus()
        If (penempatan_baru = False And txtidlokasi.Text <> "") Then
            openempatan.Hapus(txtidlokasi.Text)
            ClearEntry()
            Reload()
        End If
    End Sub
    Private Sub btnsimpan3_Click(sender As Object, e As EventArgs) Handles btnsimpan3.Click
        If (txtidlokasi.Text <> "") Then
            SimpanDataMenu()
            ClearEntry()
            Reload()
        Else
            MessageBox.Show("nota dan tanggal tidak boleh kosong!")
        End If
    End Sub


    Private Sub btnriset3_Click(sender As Object, e As EventArgs) Handles btnriset3.Click
        ClearEntry()
    End Sub
    Private Sub btnhapus3_Click(sender As Object, e As EventArgs) Handles btnhapus3.Click
        Dim jawab As Integer
        jawab = MessageBox.Show("Apakah Data akan dihapus", "Confirm", MessageBoxButtons.YesNo)
        If (jawab = vbYes) Then
            Hapus()
        Else
            MessageBox.Show("Data batal dihapus")
        End If
    End Sub

    Private Sub btncari3_Click(sender As Object, e As EventArgs) Handles btncari3.Click
        openempatan.Caripenempatan(txtidlokasi.Text)
        If (biaya_baru = False) Then
            Tampilpenempatan()
        Else
            MessageBox.Show("Data tidak ditemukan")
        End If

    End Sub
    Private Sub txtidlokasi_KeyDown(sender As Object, e As KeyEventArgs) Handles txtidlokasi.KeyDown
        If (e.KeyCode = Keys.Enter) Then
            openempatan.Caripenempatan(txtidlokasi.Text)
            If (penempatan_baru = False) Then
                Tampilpenempatan()
            End If
        Else
            MessageBox.Show("Data tidak ditemukan")
        End If
    End Sub
End Class