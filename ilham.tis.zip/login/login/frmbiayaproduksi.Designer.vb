﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmbiayaproduksi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmbiayaproduksi))
        Me.btnriset1 = New System.Windows.Forms.Button()
        Me.txtidproduksi = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtBiayapupuk = New System.Windows.Forms.TextBox()
        Me.txtBiayabibit = New System.Windows.Forms.TextBox()
        Me.txtBiayapenggarapan = New System.Windows.Forms.TextBox()
        Me.btnsimpan1 = New System.Windows.Forms.Button()
        Me.btnhapus1 = New System.Windows.Forms.Button()
        Me.btncari1 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtno1 = New System.Windows.Forms.TextBox()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnriset1
        '
        Me.btnriset1.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnriset1.Location = New System.Drawing.Point(312, 204)
        Me.btnriset1.Name = "btnriset1"
        Me.btnriset1.Size = New System.Drawing.Size(75, 23)
        Me.btnriset1.TabIndex = 0
        Me.btnriset1.Text = "Riset"
        Me.btnriset1.UseVisualStyleBackColor = True
        '
        'txtidproduksi
        '
        Me.txtidproduksi.Location = New System.Drawing.Point(243, 59)
        Me.txtidproduksi.Name = "txtidproduksi"
        Me.txtidproduksi.Size = New System.Drawing.Size(205, 20)
        Me.txtidproduksi.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(30, 58)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 18)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "ID Produksi"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(30, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(101, 18)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Biaya Pupuk"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(30, 125)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 18)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Biaya BIbit"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(30, 160)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(207, 18)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Biaya Penggarapan Lahan "
        '
        'txtBiayapupuk
        '
        Me.txtBiayapupuk.Location = New System.Drawing.Point(243, 91)
        Me.txtBiayapupuk.Name = "txtBiayapupuk"
        Me.txtBiayapupuk.Size = New System.Drawing.Size(205, 20)
        Me.txtBiayapupuk.TabIndex = 6
        '
        'txtBiayabibit
        '
        Me.txtBiayabibit.Location = New System.Drawing.Point(243, 123)
        Me.txtBiayabibit.Name = "txtBiayabibit"
        Me.txtBiayabibit.Size = New System.Drawing.Size(205, 20)
        Me.txtBiayabibit.TabIndex = 7
        '
        'txtBiayapenggarapan
        '
        Me.txtBiayapenggarapan.Location = New System.Drawing.Point(243, 158)
        Me.txtBiayapenggarapan.Name = "txtBiayapenggarapan"
        Me.txtBiayapenggarapan.Size = New System.Drawing.Size(205, 20)
        Me.txtBiayapenggarapan.TabIndex = 8
        '
        'btnsimpan1
        '
        Me.btnsimpan1.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsimpan1.Location = New System.Drawing.Point(171, 204)
        Me.btnsimpan1.Name = "btnsimpan1"
        Me.btnsimpan1.Size = New System.Drawing.Size(75, 23)
        Me.btnsimpan1.TabIndex = 9
        Me.btnsimpan1.Text = "Simpan"
        Me.btnsimpan1.UseVisualStyleBackColor = True
        '
        'btnhapus1
        '
        Me.btnhapus1.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhapus1.Location = New System.Drawing.Point(33, 204)
        Me.btnhapus1.Name = "btnhapus1"
        Me.btnhapus1.Size = New System.Drawing.Size(75, 23)
        Me.btnhapus1.TabIndex = 10
        Me.btnhapus1.Text = "Hapus"
        Me.btnhapus1.UseVisualStyleBackColor = True
        '
        'btncari1
        '
        Me.btncari1.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncari1.Location = New System.Drawing.Point(451, 204)
        Me.btncari1.Name = "btncari1"
        Me.btncari1.Size = New System.Drawing.Size(75, 23)
        Me.btncari1.TabIndex = 11
        Me.btncari1.Text = "Cari"
        Me.btncari1.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(30, 26)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(33, 18)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "NO"
        '
        'txtno1
        '
        Me.txtno1.Location = New System.Drawing.Point(243, 27)
        Me.txtno1.Name = "txtno1"
        Me.txtno1.Size = New System.Drawing.Size(205, 20)
        Me.txtno1.TabIndex = 13
        '
        'DataGridView2
        '
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Location = New System.Drawing.Point(33, 247)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(493, 150)
        Me.DataGridView2.TabIndex = 14
        '
        'frmbiayaproduksi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ClientSize = New System.Drawing.Size(613, 393)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.txtno1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btncari1)
        Me.Controls.Add(Me.btnhapus1)
        Me.Controls.Add(Me.btnsimpan1)
        Me.Controls.Add(Me.txtBiayapenggarapan)
        Me.Controls.Add(Me.txtBiayabibit)
        Me.Controls.Add(Me.txtBiayapupuk)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtidproduksi)
        Me.Controls.Add(Me.btnriset1)
        Me.Name = "frmbiayaproduksi"
        Me.Text = "frmbiayaproduksi"
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnriset1 As System.Windows.Forms.Button
    Friend WithEvents txtidproduksi As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtBiayapupuk As System.Windows.Forms.TextBox
    Friend WithEvents txtBiayabibit As System.Windows.Forms.TextBox
    Friend WithEvents txtBiayapenggarapan As System.Windows.Forms.TextBox
    Friend WithEvents btnsimpan1 As System.Windows.Forms.Button
    Friend WithEvents btnhapus1 As System.Windows.Forms.Button
    Friend WithEvents btncari1 As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtno1 As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
End Class
