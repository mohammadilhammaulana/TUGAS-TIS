﻿Public Class frmpendataan

    Private Sub frmpendataan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reload()
        opendataan.Caripendataan(txtidhasil.Text)
        If (pendataan_baru = False) Then

        Else
            MessageBox.Show("Data TerLoad")
        End If
    End Sub

    Private Sub Reload()
        opendataan.getAllData(DataGridView1)
    End Sub
    Private Sub TampilMenu()

        txtno.Text = opendataan.no
        txtidhasil.Text = opendataan.idhasil
        txthasilpertanian.Text = opendataan.hasilpertanian
        txtlokasipertanian.Text = opendataan.lokasipertanian
        txtjenispalawija.Text = opendataan.jenispalawija
        txtjumlahnominal.Text = opendataan.jumlalnominal

    End Sub
    Private Sub ClearEntry()
        txtno.Clear()
        txtidhasil.Clear()
        txthasilpertanian.Clear()
        txtlokasipertanian.Clear()
        txtjenispalawija.Clear()
        txtjumlahnominal.Clear()
        txtidhasil.Focus()
    End Sub
    Private Sub SimpanDataMenu()

        opendataan.no = txtno.Text
        opendataan.idhasil = txtidhasil.Text
        opendataan.hasilpertanian = txthasilpertanian.Text
        opendataan.lokasipertanian = txthasilpertanian.Text
        opendataan.jenispalawija = txtjenispalawija.Text
        opendataan.jumlalnominal = txtjumlahnominal.Text
       
        opendataan.Simpan()
        Reload()
        If (opendataan.InsertState = True) Then
            MessageBox.Show("Data berhasil disimpan.")
        ElseIf (opendataan.UpdateState = True) Then
            MessageBox.Show("Data berhasil diperbarui.")
        Else
            MessageBox.Show("Data gagal disimpan.")
        End If
        ClearEntry()
    End Sub
    Private Sub Hapus()
        If (pendataan_baru = False And txtidhasil.Text <> "") Then
            opendataan.Hapus(txtidhasil.Text)
            ClearEntry()
            Reload()
        End If
    End Sub
    Private Sub btnsimpan2_Click(sender As Object, e As EventArgs) Handles btnsimpan2.Click
        If (txtidhasil.Text <> "") Then
            SimpanDataMenu()
            ClearEntry()
            Reload()
        Else
            MessageBox.Show("idhasil  tidak boleh kosong!")
        End If
    End Sub
    Private Sub btnriset2_Click(sender As Object, e As EventArgs) Handles btnriset2.Click
        ClearEntry()
    End Sub
    Private Sub btnhapus2_Click(sender As Object, e As EventArgs) Handles Btnhapus2.Click
        Dim jawab As Integer
        jawab = MessageBox.Show("Apakah Data akan dihapus", "Confirm", MessageBoxButtons.YesNo)
        If (jawab = vbYes) Then
            Hapus()
        Else
            MessageBox.Show("Data batal dihapus")
        End If
    End Sub

    Private Sub btncari2_Click(sender As Object, e As EventArgs) Handles btncari2.Click

        opendataan.Caripendataan(txtidhasil.Text)
        If (pendataan_baru = False) Then
            TampilMenu()
        Else
            MessageBox.Show("Data tidak ditemukan")
        End If

    End Sub
    Private Sub txtidhasil_KeyDown(sender As Object, e As KeyEventArgs)
        If (e.KeyCode = Keys.Enter) Then
            opendataan.Caripendataan(txtidhasil.Text)
            If (pendataan_baru = False) Then
                TampilMenu()
            Else
                MessageBox.Show("Data tidak ditemukan")
            End If
        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        frmreport.Show()
    End Sub
End Class