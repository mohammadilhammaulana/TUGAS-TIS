﻿Public Class Penempatan
    Dim strsql As String
    Dim info As String
    Private _no2 As Integer
    Private _idlokasi As String
    Private _lokasi As String
    Private _luas As String
    Private _jenistanamanyangcocokdilokasitsb As String
    Public InsertState As Boolean = False
    Public UpdateState As Boolean = False
    Public DeleteState As Boolean = False
    Public Property no2()
        Get
            Return _no2
        End Get
        Set(ByVal value)
            _no2 = value
        End Set
    End Property
    Public Property idlokasi()
        Get
            Return _idlokasi
        End Get
        Set(ByVal value)
            _idlokasi = value
        End Set
    End Property
    Public Property lokasi()
        Get
            Return _lokasi
        End Get
        Set(ByVal value)
            _lokasi = value
        End Set
    End Property
    Public Property luas()
        Get
            Return _luas
        End Get
        Set(ByVal value)
            _luas = value
        End Set
    End Property
    Public Property jenistanamanyangcocokdilokasitsb()
        Get
            Return _jenistanamanyangcocokdilokasitsb
        End Get
        Set(ByVal value)
            _jenistanamanyangcocokdilokasitsb = value
        End Set
    End Property
    Public Sub Simpan()
        Dim info As String
        DBConnect()
        If (penempatan_baru = True) Then
            strsql = "Insert into penempatan(idlokasi,lokasi,luas,jenistanamanyangcocokdilokasitsb) values ('" & idlokasi & "','" & lokasi & "','" & luas & "','" & jenistanamanyangcocokdilokasitsb & "')"
            info = "INSERT"
        Else
            strsql = "update penempatan set idlokasi='" & idlokasi & "', lokasi='" & lokasi & "', luas='" & luas & "', jenistanamanyangcocokdilokasitsb='" & jenistanamanyangcocokdilokasitsb & "' where idlokasi='" & _idlokasi & "'"
            info = "UPDATE"
        End If
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
        Catch ex As Exception
            If (info = "INSERT") Then
                InsertState = False
            ElseIf (info = "UPDATE") Then
                UpdateState = False
            Else
            End If
        Finally
            If (info = "INSERT") Then
                InsertState = True
            ElseIf (info = "UPDATE") Then
                UpdateState = True
            Else
            End If
        End Try
        DBDisconnect()
    End Sub
    Public Sub Caripenempatan(ByVal sidlokasi As String)
        DBConnect()
        strsql = "SELECT * FROM penempatan WHERE idlokasi='" & sidlokasi & "'"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        DR = myCommand.ExecuteReader
        If (DR.HasRows = True) Then
            penempatan_baru = False
            DR.Read()
            idlokasi = Convert.ToString((DR("idlokasi")))
            lokasi = Convert.ToString((DR("lokasi")))
            luas = Convert.ToString((DR("luas")))
            jenistanamanyangcocokdilokasitsb = Convert.ToString((DR("jenistanamanyangcocokdilokasitsb")))
        Else
            MessageBox.Show("Data Tidak Ditemukan.")
            penempatan_baru = True
        End If
        DBDisconnect()
    End Sub
    Public Sub Hapus(ByVal sidlokasi As String)
        Dim info As String
        DBConnect()
        strsql = "DELETE FROM penempatan WHERE idlokasi='" & sidlokasi & "'"
        info = "DELETE"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
            DeleteState = True
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        DBDisconnect()
    End Sub
    Public Sub getAllData(ByVal dg As DataGridView)
        Try
            DBConnect()
            strsql = "SELECT * FROM penempatan"
            myCommand.Connection = conn
            myCommand.CommandText = strsql
            myData.Clear()
            myAdapter.SelectCommand = myCommand
            myAdapter.Fill(myData)
            With dg
                .DataSource = myData
                .AllowUserToAddRows = False
                .AllowUserToDeleteRows = False
                .ReadOnly = True
            End With
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        Finally
            DBDisconnect()
        End Try
    End Sub
End Class

