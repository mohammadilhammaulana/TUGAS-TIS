﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmpendataan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmpendataan))
        Me.txtidhasil = New System.Windows.Forms.TextBox()
        Me.txthasilpertanian = New System.Windows.Forms.TextBox()
        Me.txtlokasipertanian = New System.Windows.Forms.TextBox()
        Me.txtjenispalawija = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Btnhapus2 = New System.Windows.Forms.Button()
        Me.btnsimpan2 = New System.Windows.Forms.Button()
        Me.btnriset2 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtjumlahnominal = New System.Windows.Forms.TextBox()
        Me.btncari2 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtno = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtidhasil
        '
        Me.txtidhasil.Location = New System.Drawing.Point(174, 38)
        Me.txtidhasil.Name = "txtidhasil"
        Me.txtidhasil.Size = New System.Drawing.Size(100, 20)
        Me.txtidhasil.TabIndex = 0
        '
        'txthasilpertanian
        '
        Me.txthasilpertanian.Location = New System.Drawing.Point(174, 64)
        Me.txthasilpertanian.Name = "txthasilpertanian"
        Me.txthasilpertanian.Size = New System.Drawing.Size(100, 20)
        Me.txthasilpertanian.TabIndex = 1
        '
        'txtlokasipertanian
        '
        Me.txtlokasipertanian.Location = New System.Drawing.Point(174, 90)
        Me.txtlokasipertanian.Name = "txtlokasipertanian"
        Me.txtlokasipertanian.Size = New System.Drawing.Size(100, 20)
        Me.txtlokasipertanian.TabIndex = 2
        '
        'txtjenispalawija
        '
        Me.txtjenispalawija.Location = New System.Drawing.Point(174, 116)
        Me.txtjenispalawija.Name = "txtjenispalawija"
        Me.txtjenispalawija.Size = New System.Drawing.Size(100, 20)
        Me.txtjenispalawija.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(20, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(66, 19)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "ID Hasil"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(20, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(122, 19)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Hasil Pertanian"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(20, 91)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(133, 19)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Lokasi Pertanian"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(21, 117)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(113, 19)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Jenis Palawija"
        '
        'Btnhapus2
        '
        Me.Btnhapus2.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnhapus2.Location = New System.Drawing.Point(297, 137)
        Me.Btnhapus2.Name = "Btnhapus2"
        Me.Btnhapus2.Size = New System.Drawing.Size(75, 23)
        Me.Btnhapus2.TabIndex = 8
        Me.Btnhapus2.Text = "HAPUS"
        Me.Btnhapus2.UseVisualStyleBackColor = True
        '
        'btnsimpan2
        '
        Me.btnsimpan2.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsimpan2.Location = New System.Drawing.Point(297, 58)
        Me.btnsimpan2.Name = "btnsimpan2"
        Me.btnsimpan2.Size = New System.Drawing.Size(75, 23)
        Me.btnsimpan2.TabIndex = 9
        Me.btnsimpan2.Text = "SIMPAN"
        Me.btnsimpan2.UseVisualStyleBackColor = True
        '
        'btnriset2
        '
        Me.btnriset2.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnriset2.Location = New System.Drawing.Point(297, 97)
        Me.btnriset2.Name = "btnriset2"
        Me.btnriset2.Size = New System.Drawing.Size(75, 23)
        Me.btnriset2.TabIndex = 10
        Me.btnriset2.Text = "RISET"
        Me.btnriset2.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(19, 142)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(134, 18)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Jumlah Nominal "
        '
        'txtjumlahnominal
        '
        Me.txtjumlahnominal.Location = New System.Drawing.Point(174, 142)
        Me.txtjumlahnominal.Name = "txtjumlahnominal"
        Me.txtjumlahnominal.Size = New System.Drawing.Size(100, 20)
        Me.txtjumlahnominal.TabIndex = 12
        '
        'btncari2
        '
        Me.btncari2.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncari2.Location = New System.Drawing.Point(297, 15)
        Me.btncari2.Name = "btncari2"
        Me.btncari2.Size = New System.Drawing.Size(75, 23)
        Me.btncari2.TabIndex = 13
        Me.btncari2.Text = "CARI"
        Me.btncari2.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(21, 15)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(34, 19)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "NO"
        '
        'txtno
        '
        Me.txtno.Location = New System.Drawing.Point(174, 12)
        Me.txtno.Name = "txtno"
        Me.txtno.Size = New System.Drawing.Size(100, 20)
        Me.txtno.TabIndex = 15
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(24, 196)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(348, 150)
        Me.DataGridView1.TabIndex = 16
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(303, 172)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(46, 13)
        Me.LinkLabel1.TabIndex = 17
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Laporan"
        '
        'frmpendataan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(392, 358)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.txtno)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btncari2)
        Me.Controls.Add(Me.txtjumlahnominal)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnriset2)
        Me.Controls.Add(Me.btnsimpan2)
        Me.Controls.Add(Me.Btnhapus2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtjenispalawija)
        Me.Controls.Add(Me.txtlokasipertanian)
        Me.Controls.Add(Me.txthasilpertanian)
        Me.Controls.Add(Me.txtidhasil)
        Me.Name = "frmpendataan"
        Me.Text = "frmpendataanhasiltani"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtidhasil As System.Windows.Forms.TextBox
    Friend WithEvents txthasilpertanian As System.Windows.Forms.TextBox
    Friend WithEvents txtlokasipertanian As System.Windows.Forms.TextBox
    Friend WithEvents txtjenispalawija As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Btnhapus2 As System.Windows.Forms.Button
    Friend WithEvents btnsimpan2 As System.Windows.Forms.Button
    Friend WithEvents btnriset2 As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtjumlahnominal As System.Windows.Forms.TextBox
    Friend WithEvents btncari2 As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtno As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
End Class
