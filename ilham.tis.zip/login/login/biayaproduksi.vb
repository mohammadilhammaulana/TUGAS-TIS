﻿Public Class Biayaproduksi
    Dim strsql As String
    Dim info As String
    Private _no1 As Integer
    Private _idproduksi As String
    Private _biayapupuk As String
    Private _biayabibit As String
    Private _biayapenggarapanlahan As String
    Public InsertState As Boolean = False
    Public UpdateState As Boolean = False
    Public DeleteState As Boolean = False
    Public Property no1()
        Get
            Return _no1
        End Get
        Set(ByVal value)
            _no1 = value
        End Set
    End Property
    Public Property idproduksi()
        Get
            Return _idproduksi
        End Get
        Set(ByVal value)
            _idproduksi = value
        End Set
    End Property
    Public Property biayapupuk()
        Get
            Return _biayapupuk
        End Get
        Set(ByVal value)
            _biayapupuk = value
        End Set
    End Property
    Public Property biayabibit()
        Get
            Return _biayabibit
        End Get
        Set(ByVal value)
            _biayabibit = value
        End Set
    End Property
    Public Property biayapenggarapanlahan()
        Get
            Return _biayapenggarapanlahan
        End Get
        Set(ByVal value)
            _biayapenggarapanlahan = value
        End Set
    End Property
    Public Sub Simpan()
        Dim info As String
        DBConnect()
        If (biaya_baru = True) Then
            strsql = "Insert into biaya(idproduksi,biayapupuk,biayabibit,biayapenggarapanlahan) values ('" & _idproduksi & "','" & _biayapupuk & "','" & _biayabibit & "','" & _biayapenggarapanlahan & "')"
            info = "INSERT"
        Else
            strsql = "update biaya set idproduksi='" & _idproduksi & "', biayapupuk='" & _biayapupuk & "', biayabibit='" & _biayabibit & "', biayapenggarapanlahan='" & _biayapenggarapanlahan & "' where idproduksi='" & _idproduksi & "'"
            info = "UPDATE"
        End If
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
        Catch ex As Exception
            If (info = "INSERT") Then
                InsertState = False
            ElseIf (info = "UPDATE") Then
                UpdateState = False
            Else
            End If
        Finally
            If (info = "INSERT") Then
                InsertState = True
            ElseIf (info = "UPDATE") Then
                UpdateState = True
            Else
            End If
        End Try
        DBDisconnect()
    End Sub
    Public Sub Caribiaya(ByVal sidproduksi As String)
        DBConnect()
        strsql = "SELECT * FROM biaya WHERE idproduksi='" & sidproduksi & "'"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        DR = myCommand.ExecuteReader
        If (DR.HasRows = True) Then
            biaya_baru = False
            DR.Read()
            idproduksi = Convert.ToString((DR("idproduksi")))
            biayapupuk = Convert.ToString((DR("biayapupuk")))
            biayabibit = Convert.ToString((DR("biayabibit")))
            biayapenggarapanlahan = Convert.ToString((DR("biayapenggarapanlahan")))
        Else
            MessageBox.Show("Data Tidak Ditemukan.")
            biaya_baru = True
        End If
        DBDisconnect()
    End Sub
    Public Sub Hapus(ByVal sidproduksi As String)
        Dim info As String
        DBConnect()
        strsql = "DELETE FROM biaya WHERE idproduksi='" & sidproduksi & "'"
        info = "DELETE"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
            DeleteState = True
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        DBDisconnect()
    End Sub
    Public Sub getAllData(ByVal dg As DataGridView)
        Try
            DBConnect()
            strsql = "SELECT * FROM biaya"
            myCommand.Connection = conn
            myCommand.CommandText = strsql
            myData.Clear()
            myAdapter.SelectCommand = myCommand
            myAdapter.Fill(myData)
            With dg
                .DataSource = myData
                .AllowUserToAddRows = False
                .AllowUserToDeleteRows = False
                .ReadOnly = True
            End With
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        Finally
            DBDisconnect()
        End Try
    End Sub
End Class

