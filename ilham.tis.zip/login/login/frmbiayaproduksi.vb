﻿Public Class frmbiayaproduksi

    Private Sub frmbiayaproduksi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reload()
        obiaya.Caribiaya(txtidproduksi.Text)
        If (biaya_baru = False) Then

        Else
            MessageBox.Show("Data TerLoad")
        End If
    End Sub
    Private Sub Reload()
        obiaya.getAllData(DataGridView2)
    End Sub
    Private Sub Tampilbiaya()

        txtno1.Text = obiaya.no1
        txtidproduksi.Text = obiaya.idproduksi
        txtBiayapupuk.Text = obiaya.biayapupuk
        txtBiayabibit.Text = obiaya.biayabibit
        txtBiayapenggarapan.Text = obiaya.biayapenggarapanlahan


    End Sub
    Private Sub ClearEntry()
        txtno1.Clear()
        txtidproduksi.Clear()
        txtBiayapupuk.Clear()
        txtBiayabibit.Clear()
        txtBiayapenggarapan.Clear()
        txtidproduksi.Focus()
    End Sub
    Private Sub SimpanDataMenu()

        obiaya.no1 = txtno1.Text
        obiaya.idproduksi = txtidproduksi.Text
        obiaya.biayapupuk = txtBiayapupuk.Text
        obiaya.biayabibit = txtBiayabibit.Text
        obiaya.biayapenggarapanlahan = txtBiayapenggarapan.Text


        obiaya.Simpan()
        Reload()
        If (obiaya.InsertState = True) Then
            MessageBox.Show("Data berhasil disimpan.")
        ElseIf (obiaya.UpdateState = True) Then
            MessageBox.Show("Data berhasil diperbarui.")
        Else
            MessageBox.Show("Data gagal disimpan.")
        End If
        ClearEntry()
    End Sub

    Private Sub Hapus()
        If (biaya_baru = False And txtidproduksi.Text <> "") Then
            obiaya.Hapus(txtidproduksi.Text)
            ClearEntry()
            Reload()
        End If
    End Sub
    Private Sub btnsimpan1_Click(sender As Object, e As EventArgs) Handles btnsimpan1.Click
        If (txtidproduksi.Text <> "") Then
            SimpanDataMenu()
            ClearEntry()
            Reload()
        Else
            MessageBox.Show("nota dan tanggal tidak boleh kosong!")
        End If
    End Sub

    Private Sub btnriset1_Click(sender As Object, e As EventArgs) Handles btnriset1.Click
        ClearEntry()
    End Sub
    Private Sub btnhapus1_Click(sender As Object, e As EventArgs) Handles btnhapus1.Click
        Dim jawab As Integer
        jawab = MessageBox.Show("Apakah Data akan dihapus", "Confirm", MessageBoxButtons.YesNo)
        If (jawab = vbYes) Then
            Hapus()
        Else
            MessageBox.Show("Data batal dihapus")
        End If
    End Sub
   
    Private Sub btncari1_Click(sender As Object, e As EventArgs) Handles btncari1.Click
        obiaya.Caribiaya(txtidproduksi.Text)
        If (biaya_baru = False) Then
            Tampilbiaya()
        Else
            MessageBox.Show("Data tidak ditemukan")
        End If

    End Sub
    Private Sub txtidproduksi_KeyDown(sender As Object, e As KeyEventArgs) Handles txtidproduksi.KeyDown
        If (e.KeyCode = Keys.Enter) Then
            obiaya.Caribiaya(txtidproduksi.Text)
            If (biaya_baru = False) Then
                Tampilbiaya()
            End If
        Else
            MessageBox.Show("Data tidak ditemukan")
        End If
    End Sub

    
    
End Class