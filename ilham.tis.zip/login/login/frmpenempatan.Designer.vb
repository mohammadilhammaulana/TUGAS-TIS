﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmpenempatan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmpenempatan))
        Me.btnhapus3 = New System.Windows.Forms.Button()
        Me.btnsimpan3 = New System.Windows.Forms.Button()
        Me.btnriset3 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtidlokasi = New System.Windows.Forms.TextBox()
        Me.txtlokasi = New System.Windows.Forms.TextBox()
        Me.txtluas = New System.Windows.Forms.TextBox()
        Me.txtjnstanaman = New System.Windows.Forms.TextBox()
        Me.btncari3 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtno2 = New System.Windows.Forms.TextBox()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnhapus3
        '
        Me.btnhapus3.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhapus3.Location = New System.Drawing.Point(42, 250)
        Me.btnhapus3.Name = "btnhapus3"
        Me.btnhapus3.Size = New System.Drawing.Size(75, 23)
        Me.btnhapus3.TabIndex = 0
        Me.btnhapus3.Text = "HAPUS"
        Me.btnhapus3.UseVisualStyleBackColor = True
        '
        'btnsimpan3
        '
        Me.btnsimpan3.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsimpan3.Location = New System.Drawing.Point(158, 250)
        Me.btnsimpan3.Name = "btnsimpan3"
        Me.btnsimpan3.Size = New System.Drawing.Size(75, 23)
        Me.btnsimpan3.TabIndex = 1
        Me.btnsimpan3.Text = "SIMPAN"
        Me.btnsimpan3.UseVisualStyleBackColor = True
        '
        'btnriset3
        '
        Me.btnriset3.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnriset3.Location = New System.Drawing.Point(264, 250)
        Me.btnriset3.Name = "btnriset3"
        Me.btnriset3.Size = New System.Drawing.Size(75, 23)
        Me.btnriset3.TabIndex = 2
        Me.btnriset3.Text = "RISET"
        Me.btnriset3.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 19)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "ID Lokasi"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 100)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 19)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Lokasi"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 146)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 19)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Luas"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(12, 193)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(280, 19)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Jns Tanaman yg Cocok di Lahan Tsb"
        '
        'txtidlokasi
        '
        Me.txtidlokasi.Location = New System.Drawing.Point(298, 58)
        Me.txtidlokasi.Name = "txtidlokasi"
        Me.txtidlokasi.Size = New System.Drawing.Size(100, 20)
        Me.txtidlokasi.TabIndex = 7
        '
        'txtlokasi
        '
        Me.txtlokasi.Location = New System.Drawing.Point(298, 99)
        Me.txtlokasi.Name = "txtlokasi"
        Me.txtlokasi.Size = New System.Drawing.Size(100, 20)
        Me.txtlokasi.TabIndex = 8
        '
        'txtluas
        '
        Me.txtluas.Location = New System.Drawing.Point(298, 145)
        Me.txtluas.Name = "txtluas"
        Me.txtluas.Size = New System.Drawing.Size(100, 20)
        Me.txtluas.TabIndex = 9
        '
        'txtjnstanaman
        '
        Me.txtjnstanaman.Location = New System.Drawing.Point(298, 192)
        Me.txtjnstanaman.Name = "txtjnstanaman"
        Me.txtjnstanaman.Size = New System.Drawing.Size(100, 20)
        Me.txtjnstanaman.TabIndex = 10
        '
        'btncari3
        '
        Me.btncari3.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncari3.Location = New System.Drawing.Point(360, 250)
        Me.btncari3.Name = "btncari3"
        Me.btncari3.Size = New System.Drawing.Size(75, 23)
        Me.btncari3.TabIndex = 11
        Me.btncari3.Text = "CARI"
        Me.btncari3.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(21, 13)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(34, 19)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "NO"
        '
        'txtno2
        '
        Me.txtno2.Location = New System.Drawing.Point(298, 12)
        Me.txtno2.Name = "txtno2"
        Me.txtno2.Size = New System.Drawing.Size(100, 20)
        Me.txtno2.TabIndex = 13
        '
        'DataGridView3
        '
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Location = New System.Drawing.Point(42, 279)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.Size = New System.Drawing.Size(387, 150)
        Me.DataGridView3.TabIndex = 14
        '
        'frmpenempatan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(470, 379)
        Me.Controls.Add(Me.DataGridView3)
        Me.Controls.Add(Me.txtno2)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btncari3)
        Me.Controls.Add(Me.txtjnstanaman)
        Me.Controls.Add(Me.txtluas)
        Me.Controls.Add(Me.txtlokasi)
        Me.Controls.Add(Me.txtidlokasi)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnriset3)
        Me.Controls.Add(Me.btnsimpan3)
        Me.Controls.Add(Me.btnhapus3)
        Me.Name = "frmpenempatan"
        Me.Text = "frmpenempatanlokasipertanian"
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnhapus3 As System.Windows.Forms.Button
    Friend WithEvents btnsimpan3 As System.Windows.Forms.Button
    Friend WithEvents btnriset3 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtidlokasi As System.Windows.Forms.TextBox
    Friend WithEvents txtlokasi As System.Windows.Forms.TextBox
    Friend WithEvents txtluas As System.Windows.Forms.TextBox
    Friend WithEvents txtjnstanaman As System.Windows.Forms.TextBox
    Friend WithEvents btncari3 As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtno2 As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
End Class
