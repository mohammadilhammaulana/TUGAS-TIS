﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmperencanaan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmperencanaan))
        Me.btnhapus4 = New System.Windows.Forms.Button()
        Me.btnsimpan4 = New System.Windows.Forms.Button()
        Me.btnriset4 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtpetani = New System.Windows.Forms.TextBox()
        Me.txtlahan = New System.Windows.Forms.TextBox()
        Me.txtbibit = New System.Windows.Forms.TextBox()
        Me.txtpengairan = New System.Windows.Forms.TextBox()
        Me.txtpupuk = New System.Windows.Forms.TextBox()
        Me.btncari4 = New System.Windows.Forms.Button()
        Me.txtno3 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.DataGridView4 = New System.Windows.Forms.DataGridView()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnhapus4
        '
        Me.btnhapus4.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhapus4.Location = New System.Drawing.Point(388, 70)
        Me.btnhapus4.Name = "btnhapus4"
        Me.btnhapus4.Size = New System.Drawing.Size(75, 23)
        Me.btnhapus4.TabIndex = 0
        Me.btnhapus4.Text = "HAPUS"
        Me.btnhapus4.UseVisualStyleBackColor = True
        '
        'btnsimpan4
        '
        Me.btnsimpan4.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsimpan4.Location = New System.Drawing.Point(388, 107)
        Me.btnsimpan4.Name = "btnsimpan4"
        Me.btnsimpan4.Size = New System.Drawing.Size(75, 23)
        Me.btnsimpan4.TabIndex = 1
        Me.btnsimpan4.Text = "SIMPAN"
        Me.btnsimpan4.UseVisualStyleBackColor = True
        '
        'btnriset4
        '
        Me.btnriset4.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnriset4.Location = New System.Drawing.Point(388, 147)
        Me.btnriset4.Name = "btnriset4"
        Me.btnriset4.Size = New System.Drawing.Size(75, 23)
        Me.btnriset4.TabIndex = 2
        Me.btnriset4.Text = "RISET"
        Me.btnriset4.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(40, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 18)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "ID Petani"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(39, 107)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 19)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Lahan"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(43, 151)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 19)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Bibit"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(39, 194)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 19)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Pengairan"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(39, 240)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 19)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Pupuk"
        '
        'txtpetani
        '
        Me.txtpetani.Location = New System.Drawing.Point(196, 57)
        Me.txtpetani.Name = "txtpetani"
        Me.txtpetani.Size = New System.Drawing.Size(100, 20)
        Me.txtpetani.TabIndex = 8
        '
        'txtlahan
        '
        Me.txtlahan.Location = New System.Drawing.Point(196, 104)
        Me.txtlahan.Name = "txtlahan"
        Me.txtlahan.Size = New System.Drawing.Size(100, 20)
        Me.txtlahan.TabIndex = 9
        '
        'txtbibit
        '
        Me.txtbibit.Location = New System.Drawing.Point(196, 150)
        Me.txtbibit.Name = "txtbibit"
        Me.txtbibit.Size = New System.Drawing.Size(100, 20)
        Me.txtbibit.TabIndex = 10
        '
        'txtpengairan
        '
        Me.txtpengairan.Location = New System.Drawing.Point(196, 193)
        Me.txtpengairan.Name = "txtpengairan"
        Me.txtpengairan.Size = New System.Drawing.Size(100, 20)
        Me.txtpengairan.TabIndex = 11
        '
        'txtpupuk
        '
        Me.txtpupuk.Location = New System.Drawing.Point(196, 239)
        Me.txtpupuk.Name = "txtpupuk"
        Me.txtpupuk.Size = New System.Drawing.Size(100, 20)
        Me.txtpupuk.TabIndex = 12
        '
        'btncari4
        '
        Me.btncari4.Font = New System.Drawing.Font("Microsoft YaHei", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncari4.Location = New System.Drawing.Point(388, 190)
        Me.btncari4.Name = "btncari4"
        Me.btncari4.Size = New System.Drawing.Size(75, 23)
        Me.btncari4.TabIndex = 13
        Me.btncari4.Text = "CARI"
        Me.btncari4.UseVisualStyleBackColor = True
        '
        'txtno3
        '
        Me.txtno3.Location = New System.Drawing.Point(196, 12)
        Me.txtno3.Name = "txtno3"
        Me.txtno3.Size = New System.Drawing.Size(100, 20)
        Me.txtno3.TabIndex = 14
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(43, 15)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(34, 19)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "NO"
        '
        'DataGridView4
        '
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.Location = New System.Drawing.Point(43, 282)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.Size = New System.Drawing.Size(478, 163)
        Me.DataGridView4.TabIndex = 16
        '
        'frmperencanaan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ClientSize = New System.Drawing.Size(616, 444)
        Me.Controls.Add(Me.DataGridView4)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtno3)
        Me.Controls.Add(Me.btncari4)
        Me.Controls.Add(Me.txtpupuk)
        Me.Controls.Add(Me.txtpengairan)
        Me.Controls.Add(Me.txtbibit)
        Me.Controls.Add(Me.txtlahan)
        Me.Controls.Add(Me.txtpetani)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnriset4)
        Me.Controls.Add(Me.btnsimpan4)
        Me.Controls.Add(Me.btnhapus4)
        Me.Name = "frmperencanaan"
        Me.Text = "frmperencanaan"
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnhapus4 As System.Windows.Forms.Button
    Friend WithEvents btnsimpan4 As System.Windows.Forms.Button
    Friend WithEvents btnriset4 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtpetani As System.Windows.Forms.TextBox
    Friend WithEvents txtlahan As System.Windows.Forms.TextBox
    Friend WithEvents txtbibit As System.Windows.Forms.TextBox
    Friend WithEvents txtpengairan As System.Windows.Forms.TextBox
    Friend WithEvents txtpupuk As System.Windows.Forms.TextBox
    Friend WithEvents btncari4 As System.Windows.Forms.Button
    Friend WithEvents txtno3 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents DataGridView4 As System.Windows.Forms.DataGridView
End Class
