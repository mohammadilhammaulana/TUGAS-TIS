﻿Public Class frmperencanaan

    Private Sub frmperencanaan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reload()
        operencanaan.Cariperencanaan(txtpetani.Text)
        If (perencanaan_baru = False) Then

        Else
            MessageBox.Show("Data TerLoad")
        End If
    End Sub
    Private Sub Reload()
        operencanaan.getAllData(DataGridView4)

    End Sub
    Private Sub Tampilperencanaan()

        txtno3.Text = operencanaan.no3
        txtpetani.Text = operencanaan.idpetani
        txtlahan.Text = operencanaan.lahan
        txtbibit.Text = operencanaan.bibit
        txtpengairan.Text = operencanaan.pengairan
        txtpupuk.Text = operencanaan.pupuk


    End Sub
    Private Sub ClearEntry()
        txtno3.Clear()
        txtpetani.Clear()
        txtlahan.Clear()
        txtbibit.Clear()
        txtpengairan.Clear()
        txtpupuk.Clear()
        txtpetani.Focus()
    End Sub
    Private Sub SimpanDataMenu()

        operencanaan.no3 = txtno3.Text
        operencanaan.idpetani = txtpetani.Text
        operencanaan.lahan = txtlahan.Text
        operencanaan.bibit = txtbibit.Text
        operencanaan.pengairan = txtpengairan.Text
        operencanaan.pupuk = txtpupuk.Text



        operencanaan.Simpan()
        Reload()
        If (operencanaan.InsertState = True) Then
            MessageBox.Show("Data berhasil disimpan.")
        ElseIf (operencanaan.UpdateState = True) Then
            MessageBox.Show("Data berhasil diperbarui.")
        Else
            MessageBox.Show("Data gagal disimpan.")
        End If
        ClearEntry()
    End Sub
    Private Sub Hapus()
        If (perencanaan_baru = False And txtpetani.Text <> "") Then
            operencanaan.Hapus(txtpetani.Text)
            ClearEntry()
            Reload()
        End If
    End Sub
    Private Sub btnsimpan4_Click(sender As Object, e As EventArgs) Handles btnsimpan4.Click
        If (txtpetani.Text <> "") Then
            SimpanDataMenu()
            ClearEntry()
            Reload()
        Else
            MessageBox.Show("nota dan tanggal tidak boleh kosong!")
        End If
    End Sub

    Private Sub btnriset4_Click(sender As Object, e As EventArgs) Handles btnriset4.Click
        ClearEntry()
    End Sub
    Private Sub btnhapus4_Click(sender As Object, e As EventArgs) Handles btnhapus4.Click
        Dim jawab As Integer
        jawab = MessageBox.Show("Apakah Data akan dihapus", "Confirm", MessageBoxButtons.YesNo)
        If (jawab = vbYes) Then
            Hapus()
        Else
            MessageBox.Show("Data batal dihapus")
        End If
    End Sub

    Private Sub btncari4_Click(sender As Object, e As EventArgs) Handles btncari4.Click
        operencanaan.Cariperencanaan(txtpetani.Text)
        If (perencanaan_baru = False) Then
            Tampilperencanaan()
        Else
            MessageBox.Show("Data tidak ditemukan")
        End If
    End Sub
    Private Sub txtpetani_KeyDown(sender As Object, e As KeyEventArgs) Handles txtpetani.KeyDown
        If (e.KeyCode = Keys.Enter) Then
            operencanaan.Cariperencanaan(txtpetani.Text)
            If (penempatan_baru = False) Then
                Tampilperencanaan()
            End If
        Else
            MessageBox.Show("Data tidak ditemukan")
        End If
    End Sub

   
   
  
    
End Class