﻿Public Class frmlogin

    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        login_valid = oUser.Login(txtusername.Text, txtpassword.Text)
        If (login_valid = True) Then
            frmmenu.Show()
            Me.Hide()
        Else
            MessageBox.Show("Login Not Valid")
        End If

    End Sub

    Private Sub frmlogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
