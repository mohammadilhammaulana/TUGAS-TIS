﻿Public Class Pendataan
    Dim strsql As String
    Dim info As String
    Private _no As Integer
    Private _idhasil As Integer
    Private _hasilpertanian As String
    Private _lokasipertanian As String
    Private _jenispalawija As String
    Private _jumlalnominal As String
    Public InsertState As Boolean = False
    Public UpdateState As Boolean = False
    Public DeleteState As Boolean = False
    Public Property no()
        Get
            Return _no
        End Get
        Set(ByVal value)
            _no = value
        End Set
    End Property
    Public Property idhasil()
        Get
            Return _idhasil
        End Get
        Set(ByVal value)
            _idhasil = value
        End Set
    End Property
    Public Property hasilpertanian()
        Get
            Return _hasilpertanian
        End Get
        Set(ByVal value)
            _hasilpertanian = value
        End Set
    End Property
    Public Property lokasipertanian()
        Get
            Return _lokasipertanian
        End Get
        Set(ByVal value)
            _lokasipertanian = value
        End Set
    End Property
    Public Property jenispalawija()
        Get
            Return _jenispalawija
        End Get
        Set(ByVal value)
            _jenispalawija = value
        End Set
    End Property
    Public Property jumlalnominal()
        Get
            Return _jumlalnominal
        End Get
        Set(ByVal value)
            _jumlalnominal = value
        End Set
    End Property
    Public Sub Simpan()
        Dim info As String
        DBConnect()
        If (pendataan_baru = True) Then
            strsql = "Insert into pendataan(idhasil,hasilpertanian,lokasipertanian,jenispalawija,jumlalnominal) values ('" & idhasil & "','" & hasilpertanian & "','" & lokasipertanian & "','" & jenispalawija & "','" & jumlalnominal & "')"
            info = "INSERT"
        Else
            strsql = "update pendataan set idhasil='" & idhasil & "', hasilpertanian='" & hasilpertanian & "', lokasipertanian='" & lokasipertanian & "', jenispalawija='" & jenispalawija & "', jumlalnominal='" & jumlalnominal & "' where idhasil='" & idhasil & "'"
            info = "UPDATE"
        End If
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
        Catch ex As Exception
            If (info = "INSERT") Then
                InsertState = False
            ElseIf (info = "UPDATE") Then
                UpdateState = False
            Else
            End If
        Finally
            If (info = "INSERT") Then
                InsertState = True
            ElseIf (info = "UPDATE") Then
                UpdateState = True
            Else
            End If
        End Try
        DBDisconnect()
    End Sub
    Public Sub Caripendataan(ByVal sidhasil As String)
        DBConnect()
        strsql = "SELECT * FROM pendataan WHERE idhasil='" & sidhasil & "'"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        DR = myCommand.ExecuteReader
        If (DR.HasRows = True) Then
            pendataan_baru = False
            DR.Read()
            idhasil = Convert.ToString((DR("idhasil")))
            hasilpertanian = Convert.ToString((DR("hasilpertanian")))
            lokasipertanian = Convert.ToString((DR("lokasipertanian")))
            jenispalawija = Convert.ToString((DR("jenispalawija")))
            jumlalnominal = Convert.ToString((DR("jumlalnominal")))
        Else
            MessageBox.Show("Data Tidak Ditemukan.")
            pendataan_baru = True
        End If
        DBDisconnect()
    End Sub
    Public Sub Hapus(ByVal sidhasil As String)
        Dim info As String
        DBConnect()
        strsql = "DELETE FROM pendataan WHERE idhasil='" & sidhasil & "'"
        info = "DELETE"
        myCommand.Connection = conn
        myCommand.CommandText = strsql
        Try
            myCommand.ExecuteNonQuery()
            DeleteState = True
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
        DBDisconnect()
    End Sub
    Public Sub getAllData(ByVal dg As DataGridView)
        Try
            DBConnect()
            strsql = "SELECT * FROM pendataan"
            myCommand.Connection = conn
            myCommand.CommandText = strsql
            myData.Clear()
            myAdapter.SelectCommand = myCommand
            myAdapter.Fill(myData)
            With dg
                .DataSource = myData
                .AllowUserToAddRows = False
                .AllowUserToDeleteRows = False
                .ReadOnly = True
            End With
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        Finally
            DBDisconnect()
        End Try
    End Sub
End Class
